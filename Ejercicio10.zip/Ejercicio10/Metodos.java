package Ejercicio10;

public class Metodos {
    Nodo inicio;
    Nodo fin;

    public Metodos() {
        inicio = null;
        fin = null;
    }

    public void insertar(String elemento) {
        Nodo nuevo = new Nodo(elemento);
        if (vacia()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            fin.sig = nuevo;
            fin = nuevo;
        }
    }

    public String eliminarUltimo() {
        if (vacia()) {
            System.out.println("La pila está vacía. No se puede eliminar ningún elemento.");
            return null;
        } else if (inicio == fin) {
            // Si hay solo un elemento en la pila
            String elemento = inicio.elemento;
            inicio = null;
            fin = null;
            return elemento;
        } else {
            // Si hay más de un elemento en la pila
            Nodo aux = inicio;
            while (aux.sig != fin) {
                aux = aux.sig;
            }
            String elemento = fin.elemento;
            aux.sig = null;
            fin = aux;
            return elemento;
        }
    }

    public boolean vacia() {
        return inicio == null;
    }
}
