/* 
 * Programa: Pilas
 * 
 * Descripción: Este programa evalúa una expresión matemática ingresada por el usuario que contiene números y operadores básicos (+, -, *, /).
 * Primero, separa los números y operadores de la expresión y los almacena en las respectivas pilas.
 * Luego, realiza las operaciones aritméticas siguiendo el orden de precedencia de los operadores y muestra el resultado final.
 */
package Ejercicio10;

import java.util.Scanner;

public class Pilas {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        Metodos operadores = new Metodos();
        Metodos numeros = new Metodos(); // Se agregó la pila para los números
        String expresion;

        do {
            System.out.println("Escriba la expresión a evaluar: ");
            expresion = lector.nextLine();
        } while (!expresion.matches("[0-9+\\-*/=]+"));

        // Sección 1: Mostrar los números
        System.out.println("\nSección 1: Números");
        mostrarNumerosSeparados(expresion);

        // Enviar a pilas números y operadores
        for (char c : expresion.toCharArray()) {
            if (Character.isDigit(c)) {
                // Si es un dígito, agrégalo a la pila de números
                numeros.insertar(String.valueOf(c));
            } else {
                // Si es un operador, agrégalo a la pila de operadores
                operadores.insertar(String.valueOf(c));
            }
        }

        int resul = 0;
        while (!operadores.vacia()) {
            // Sacar 1 operador
            String operador = operadores.eliminarUltimo();

            // Sacar 2 números
            int num2 = Integer.parseInt(numeros.eliminarUltimo());
            int num1 = Integer.parseInt(numeros.eliminarUltimo());

            // Realizar la operación según el operador
            switch (operador) {
                case "+":
                    resul = num1 + num2;
                    break;
                case "-":
                    resul = num1 - num2;
                    break;
                case "*":
                    resul = num1 * num2;
                    break;
                case "/":
                    if (num2 != 0) {
                        resul = num1 / num2;
                    } else {
                        System.out.println("Error: División por cero");
                        return;
                    }
                    break;
            } // Fin switch

            // Insertar el resultado en la pila de números
            numeros.insertar(String.valueOf(resul));
        } // Fin while

        // Sección 2: Mostrar los operadores
        System.out.println("\nSección 2: Operadores");
        mostrarOperadoresSeparados(expresion);

        // Sección 3: Mostrar el resultado final
        System.out.println("\nSección 3: Resultado Final");
        System.out.println("Resultado final: " + resul);
    }

    public static void mostrarNumerosSeparados(String expresion) {
        for (char c : expresion.toCharArray()) {
            if (Character.isDigit(c)) {
                System.out.println(c);
            }
        }
    }

    public static void mostrarOperadoresSeparados(String expresion) {
        for (char c : expresion.toCharArray()) {
            if (!Character.isDigit(c) && c != '=') {
                System.out.println(c);
            }
        }
    }
}
