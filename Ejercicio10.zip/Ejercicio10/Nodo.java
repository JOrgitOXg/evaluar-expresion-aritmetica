package Ejercicio10;

public class Nodo {
    String elemento;
    Nodo sig;

    public Nodo(String elemento) {
        this.elemento = elemento;
        this.sig = null;
    }
}